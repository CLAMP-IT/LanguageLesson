(function() {
  window.LanguageLesson = {
    Models: {},
    Collections: {},
    Routers: {},
    Views: {}
  };

}).call(this);
