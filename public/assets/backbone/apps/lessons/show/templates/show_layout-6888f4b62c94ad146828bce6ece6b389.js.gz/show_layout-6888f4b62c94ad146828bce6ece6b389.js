"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lessons/show/templates/show_layout"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<div id='info-region'></div>\n<div id='elements-region'></div>");
      return $o.join("\n").replace(/\s(?:id|class)=(['"])(\1)/mg, "");
    }).call(window.HAML.context(context));
  });;
}).call(this);
