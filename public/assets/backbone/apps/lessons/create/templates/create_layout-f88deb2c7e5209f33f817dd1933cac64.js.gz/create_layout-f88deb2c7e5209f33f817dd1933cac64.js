"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lessons/create/templates/create_layout"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<div id='palette-region'></div>\n<div id='arrangement-region'></div>\n<div id='editing-region'></div>");
      return $o.join("\n").replace(/\s(?:id|class)=(['"])(\1)/mg, "");
    }).call(window.HAML.context(context));
  });;
}).call(this);
