"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lessons/create/templates/create_palette"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<div class='palette-item' id='content-block'>\n  CONTENT BLOCK\n</div>\n<div class='palette-item' id='prompted-audio-block'>\n  LISTEN & RESPOND\n</div>\n<div class='palette-item' id='confirmed-audio-block'>\n  LISTEN, RESPOND & CONFIRM\n</div>");
      return $o.join("\n").replace(/\s(?:id|class)=(['"])(\1)/mg, "");
    }).call(window.HAML.context(context));
  });;
}).call(this);
