"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lessons/create/templates/create_arrangement"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("arrangement stuff");
      return $o.join("\n");
    }).call(window.HAML.context(context));
  });;
}).call(this);
