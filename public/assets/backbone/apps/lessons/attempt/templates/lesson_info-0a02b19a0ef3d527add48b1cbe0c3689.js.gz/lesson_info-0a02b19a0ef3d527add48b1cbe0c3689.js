"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lessons/attempt/templates/lesson_info"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<h3>" + this.name + "</h3>");
      return $o.join("\n");
    }).call(window.HAML.context(context));
  });;
}).call(this);
