"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lesson_attempts/list/templates/list_layout"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<h1>Lesson Attempts</h1>\n<div id='attempts-region'></div>");
      return $o.join("\n").replace(/\s(?:id|class)=(['"])(\1)/mg, "");
    }).call(window.HAML.context(context));
  });;
}).call(this);
