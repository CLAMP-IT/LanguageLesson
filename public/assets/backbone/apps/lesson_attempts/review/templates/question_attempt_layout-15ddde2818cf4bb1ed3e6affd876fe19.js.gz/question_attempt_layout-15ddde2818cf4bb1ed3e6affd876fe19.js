"use strict";

(function() { this.JST || (this.JST = {}); this.JST["backbone/apps/lesson_attempts/review/templates/question_attempt_layout"] = (function(context) {
    return (function() {
      var $o;
      $o = [];
      $o.push("<div id='question-attempt-region'></div>\n<div id='responses'>\n  <h4>Select an area of the waveform to add feedback.</h4>\n</div>\n<div id='responses-region'></div>");
      return $o.join("\n").replace(/\s(?:id|class)=(['"])(\1)/mg, "");
    }).call(window.HAML.context(context));
  });;
}).call(this);
