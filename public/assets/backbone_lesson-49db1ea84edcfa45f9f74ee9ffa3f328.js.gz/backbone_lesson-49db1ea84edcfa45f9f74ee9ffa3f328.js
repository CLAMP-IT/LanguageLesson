(function() {
  $(function() {
    return LanguageLesson.start({
      currentUser: gon.current_user
    });
  });

}).call(this);
